package com.example.springboot_on_minikube;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootOnMinikubeApplicationTests {

	@Test
	void contextLoads() {
	}

}
