package com.example.springboot_on_minikube;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootOnMinikubeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootOnMinikubeApplication.class, args);
	}

}
